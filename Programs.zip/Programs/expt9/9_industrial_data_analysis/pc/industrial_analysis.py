"""
Experiment 9 - Industrial Data Analysis  (PC side, Windows 11)
==============================================================
What this script does
  1. LOG     : reads DATA lines from the Arduino, adds a timestamp, saves
               data/normal.csv  (healthy machine)  or  data/fault.csv  (fault injected)
  2. ANALYZE : with pandas / NumPy / scikit-learn / Matplotlib
               - statistics: min, max, mean, std dev, moving average
               - Z-score anomaly detection (|z| > 3, using the NORMAL run as reference)
               - IsolationForest (machine learning) trained on the NORMAL run,
                 saved with joblib to model/iforest.joblib and re-loaded to test the FAULT run
               - plots: time series with anomaly markers + histograms
                 -> data/report.png
  3. DEMO    : makes synthetic normal + fault data and runs the analysis,
               so you can test without hardware.

Setup (once, PowerShell inside this experiment folder)
  py -m pip install -r requirements.txt

How to run
  py pc\\industrial_analysis.py ports
  py pc\\industrial_analysis.py log --port COM3 --label normal --seconds 120
  py pc\\industrial_analysis.py log --port COM3 --label fault  --seconds 120
        (during the fault run: warm the DHT11 with your fingers / a hairdryer,
         and turn the potentiometer quickly to fake vibration)
  py pc\\industrial_analysis.py analyze
  py pc\\industrial_analysis.py demo            # no hardware needed

Notes
  * Close the Arduino Serial Monitor before logging.
  * DHT11 is slow and only about +/-2 C accurate: treat the results as
    TREND and ANOMALY detection, not precise measurement.
"""
import argparse
import os
import time
from datetime import datetime, timedelta

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

BAUD = 9600
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DATA_DIR = os.path.join(BASE, "data")
MODEL_PATH = os.path.join(BASE, "model", "iforest.joblib")

FEATURES = ["temp_c", "hum_pct", "analog"]
MIN_STD = {"temp_c": 0.5, "hum_pct": 1.0, "analog": 3.0}   # about the sensor resolution
Z_LIMIT = 3.0
MA_WINDOW = 5


def csv_path(label):
    return os.path.join(DATA_DIR, f"{label}.csv")


# ---------------------------------------------------------------- logging
def list_ports():
    from serial.tools import list_ports as lp
    for p in lp.comports():
        print(f"{p.device}  -  {p.description}")


def log_run(port, label, seconds):
    import serial
    os.makedirs(DATA_DIR, exist_ok=True)
    ser = serial.Serial(port, BAUD, timeout=2)
    time.sleep(2.5)                       # Uno resets when the port opens
    ser.reset_input_buffer()
    print(f"Logging '{label}' for {seconds} s ... (Ctrl+C to stop early)")

    rows, t_end = [], time.time() + seconds
    try:
        while time.time() < t_end:
            line = ser.readline().decode(errors="ignore").strip()
            if not line.startswith("DATA,"):
                continue
            try:
                _, t, h, a = line.split(",")
                row = {"timestamp": datetime.now().isoformat(timespec="seconds"),
                       "temp_c": float(t), "hum_pct": float(h), "analog": float(a)}
            except ValueError:
                continue
            rows.append(row)
            print(row)
    except KeyboardInterrupt:
        print("Stopped early.")
    finally:
        ser.close()

    pd.DataFrame(rows).to_csv(csv_path(label), index=False)
    print(f"Saved {len(rows)} rows -> {os.path.abspath(csv_path(label))}")


# ---------------------------------------------------------------- demo data
def make_demo(seconds=120):
    os.makedirs(DATA_DIR, exist_ok=True)
    rng = np.random.default_rng(42)
    start = datetime.now() - timedelta(seconds=2 * seconds)

    def build(fault):
        temp = np.round(28 + rng.normal(0, 0.4, seconds))
        hum = np.round(55 + rng.normal(0, 1.2, seconds))
        analog = np.round(512 + rng.normal(0, 4, seconds))
        if fault:
            temp[60:90] += np.linspace(0, 10, 30)            # overheating
            hum[60:90] -= np.linspace(0, 8, 30)
            spikes = rng.random(seconds) < 0.25
            analog[60:90] += np.where(spikes[60:90], rng.integers(60, 200, 30), 0)
        ts = [(start + timedelta(seconds=i + (seconds if fault else 0))
               ).isoformat(timespec="seconds") for i in range(seconds)]
        return pd.DataFrame({"timestamp": ts, "temp_c": np.round(temp),
                             "hum_pct": np.round(hum), "analog": analog})

    build(False).to_csv(csv_path("normal"), index=False)
    build(True).to_csv(csv_path("fault"), index=False)


# ---------------------------------------------------------------- analysis
def load(label):
    path = csv_path(label)
    if not os.path.exists(path):
        raise SystemExit(f"Missing {path} - run 'log --label {label}' first (or use 'demo').")
    df = pd.read_csv(path, parse_dates=["timestamp"]).dropna()
    df["t_s"] = (df["timestamp"] - df["timestamp"].iloc[0]).dt.total_seconds()
    df["temp_ma"] = df["temp_c"].rolling(MA_WINDOW, min_periods=1).mean()   # moving average
    return df


def analyze(show=True):
    normal, fault = load("normal"), load("fault")

    # --- 1. descriptive statistics --------------------------------------
    for name, df in (("NORMAL", normal), ("FAULT", fault)):
        print(f"\n=== {name} run: {len(df)} samples ===")
        print(df[FEATURES].agg(["min", "max", "mean", "std"]).round(2).to_string())

    # --- 2. Z-score detection (reference = normal run) -------------------
    ref_mean = normal[FEATURES].mean()
    ref_std = normal[FEATURES].std()
    floor = pd.Series(MIN_STD)
    ref_std = ref_std.where(ref_std > floor, floor)          # avoid dividing by ~0
    for df in (normal, fault):
        z = (df[FEATURES] - ref_mean) / ref_std
        df["z_flag"] = (z.abs() > Z_LIMIT).any(axis=1)

    # --- 3. Machine learning: IsolationForest, saved/loaded with joblib --
    model = make_pipeline(StandardScaler(),
                          IsolationForest(n_estimators=100, contamination=0.02,
                                          random_state=42))
    model.fit(normal[FEATURES])                              # learn "healthy" behaviour
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"\nModel saved -> {os.path.abspath(MODEL_PATH)}")
    model = joblib.load(MODEL_PATH)                          # re-use the saved model
    for df in (normal, fault):
        df["ml_flag"] = model.predict(df[FEATURES]) == -1

    # --- 4. summary table -------------------------------------------------
    summary = pd.DataFrame({
        "samples": [len(normal), len(fault)],
        "z_score_anomalies": [int(normal["z_flag"].sum()), int(fault["z_flag"].sum())],
        "isolation_forest_anomalies": [int(normal["ml_flag"].sum()), int(fault["ml_flag"].sum())],
    }, index=["normal", "fault"])
    print("\n=== Anomaly summary ===")
    print(summary.to_string())
    print("\nExpected: very few flags in 'normal', many in 'fault'.")

    # --- 5. plots ---------------------------------------------------------
    fig, ax = plt.subplots(2, 2, figsize=(12, 8))
    for col, (name, df) in enumerate((("normal", normal), ("fault", fault))):
        a = ax[0][col]
        a.plot(df["t_s"], df["temp_c"], color="lightsteelblue", label="temperature")
        a.plot(df["t_s"], df["temp_ma"], color="navy", label=f"moving avg ({MA_WINDOW})")
        z = df[df["z_flag"]]
        m = df[df["ml_flag"]]
        a.scatter(z["t_s"], z["temp_c"], marker="x", color="red", zorder=3, label="Z-score anomaly")
        a.scatter(m["t_s"], m["temp_c"], facecolors="none", edgecolors="orange",
                  s=90, zorder=3, label="IsolationForest anomaly")
        a.set_title(f"Temperature - {name} run")
        a.set_xlabel("Time (s)")
        a.set_ylabel("deg C")
        a.legend(fontsize=8)
        a.grid(True, alpha=0.3)

    ax[1][0].hist(normal["temp_c"], bins=15, alpha=0.6, label="normal")
    ax[1][0].hist(fault["temp_c"], bins=15, alpha=0.6, label="fault")
    ax[1][0].set_title("Temperature histogram")
    ax[1][0].set_xlabel("deg C")
    ax[1][0].legend()
    ax[1][1].hist(normal["analog"], bins=15, alpha=0.6, label="normal")
    ax[1][1].hist(fault["analog"], bins=15, alpha=0.6, label="fault")
    ax[1][1].set_title("Analog (vibration stand-in) histogram")
    ax[1][1].set_xlabel("ADC value")
    ax[1][1].legend()
    fig.tight_layout()

    out = os.path.join(DATA_DIR, "report.png")
    fig.savefig(out, dpi=120)
    print(f"Report chart saved -> {os.path.abspath(out)}")
    if show:
        plt.show()


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Exp 9 - Industrial data analysis")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("ports", help="list serial ports")
    p = sub.add_parser("log", help="record a run from the Arduino")
    p.add_argument("--port", required=True, help="e.g. COM3")
    p.add_argument("--label", choices=["normal", "fault"], required=True)
    p.add_argument("--seconds", type=int, default=120)
    p = sub.add_parser("analyze", help="analyze normal.csv and fault.csv")
    p.add_argument("--no-show", action="store_true", help="save chart only")
    sub.add_parser("demo", help="synthetic data + analysis, no hardware")

    args = ap.parse_args()
    if args.cmd == "ports":
        list_ports()
    elif args.cmd == "log":
        log_run(args.port, args.label, args.seconds)
    elif args.cmd == "analyze":
        analyze(show=not args.no_show)
    elif args.cmd == "demo":
        make_demo()
        analyze(show=True)


if __name__ == "__main__":
    main()
