/*
  Experiment 9 - Industrial Data Analysis  (Arduino Uno side: data acquisition)
  --------------------------------------------------------------------------
  Reads a DHT11 (temperature, humidity) and an analog sensor once per second
  and prints one CSV line:
        DATA,temp_c,hum_pct,analog

  The analog channel is a stand-in for a machine signal such as vibration or
  pressure: use a potentiometer (turn it quickly to simulate a fault) or an LDR.

  Wiring
    DHT11 DATA -> D2   (VCC 5V, GND; use the 3-pin module or add a 10k pull-up)
    Pot / LDR divider -> A0

  Library (Arduino IDE -> Library Manager)
    "DHT sensor library" by Adafruit  (also install "Adafruit Unified Sensor" if asked)

  Serial: 9600 baud. The PC script adds the timestamps.
  Note: DHT11 is slow (~1 sample/s) and only about +/-2 C accurate.
*/

#include <DHT.h>

#define DHTPIN  2
#define DHTTYPE DHT11
const uint8_t PIN_ANALOG = A0;
const unsigned long SAMPLE_EVERY_MS = 1000;

DHT dht(DHTPIN, DHTTYPE);
unsigned long lastSampleMs = 0;

void setup() {
  Serial.begin(9600);
  dht.begin();
  Serial.println(F("# Exp 9 logger ready. Columns: DATA,temp_c,hum_pct,analog"));
  lastSampleMs = millis();
}

void loop() {
  unsigned long now = millis();
  if (now - lastSampleMs < SAMPLE_EVERY_MS) return;
  lastSampleMs = now;

  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int   a = analogRead(PIN_ANALOG);

  if (isnan(t) || isnan(h)) {            // DHT11 occasionally fails - skip that sample
    Serial.println(F("# DHT read failed, sample skipped"));
    return;
  }

  Serial.print(F("DATA,"));
  Serial.print(t, 1);  Serial.print(',');
  Serial.print(h, 1);  Serial.print(',');
  Serial.println(a);
}
