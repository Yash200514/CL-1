# Experiment 9 - Industrial Data Analysis

**Aim:** Acquire sensor data from an Arduino Uno, store it, analyze it with Python,
and detect abnormal behaviour by comparing a *normal* run with a *fault-injected* run.

## Pipeline
| Stage | What happens | Tool |
|---|---|---|
| Acquire | Uno prints `DATA,temp,hum,analog` every second | Arduino + DHT11 + pot |
| Store | PC adds timestamps, saves CSV | pandas |
| Analyze | min / max / mean / std, moving average | pandas, NumPy |
| Detect | Z-score rule + IsolationForest (model saved with joblib) | scikit-learn, joblib |
| Visualize | time series with anomaly markers, histograms | Matplotlib |

## Hardware
| Part | Pin |
|---|---|
| DHT11 DATA | D2 |
| Potentiometer or LDR divider (vibration/pressure stand-in) | A0 |

## Files
```
arduino/industrial_logger/industrial_logger.ino   Uno sketch (needs "DHT sensor library" by Adafruit)
pc/industrial_analysis.py                         log + analyze (Windows 11 / Python 3.9+)
requirements.txt
data/    CSVs + report.png are created here
model/   iforest.joblib is created here
```

## Steps
1. Install the **DHT sensor library** (Adafruit) in Arduino IDE, upload the sketch.
2. PowerShell inside this folder:
   ```
   py -m pip install -r requirements.txt
   py pc\industrial_analysis.py ports
   py pc\industrial_analysis.py log --port COM3 --label normal --seconds 120
   py pc\industrial_analysis.py log --port COM3 --label fault  --seconds 120
   py pc\industrial_analysis.py analyze
   ```
   * Normal run: leave everything undisturbed.
   * Fault run: after ~40 s warm the DHT11 (fingers / hairdryer, keep it safe) and twist the potentiometer sharply.
3. No hardware yet? `py pc\industrial_analysis.py demo`

## Report checklist
Statistics table for both runs, the anomaly summary table, `data/report.png`, and 3-4 lines on why the fault run was flagged.

## Notes
* DHT11 is slow (about 1 sample/s) and only +/-2 C accurate: frame results as **trend and anomaly detection**, not precise measurement.
* The model is trained only on the normal run, so it learns "healthy" behaviour. Collect a longer normal run for better results.
* Z-score = how many standard deviations a value is from the normal mean (rule of thumb: |z| > 3 is unusual).
* Close the Arduino Serial Monitor before logging.
* Educational use only.
