/*
  Servo control from a webpage: Arduino Uno + ESP-01 (AT firmware)

  Wiring:
    ESP-01 TX   -> Uno pin 6  (Uno RX)
    ESP-01 RX   -> Uno pin 7  (Uno TX) THROUGH A 5V->3.3V DIVIDER (e.g. 1k + 2k)
    ESP-01 VCC, CH_PD(EN) -> 3.3V (needs ~300 mA, use a proper 3.3V supply)
    ESP-01 GND  -> GND (common with Uno and servo)
    Servo signal -> Uno pin 5, servo power from external 5V (common GND)

  One-time ESP-01 setup (talk to it at its current baud, usually 115200):
    AT+UART_DEF=9600,8,1,0,0
  SoftwareSerial is unreliable at 115200.
*/

#include <SoftwareSerial.h>
#include <Servo.h>

const char WIFI_SSID[] = "Microembedded";
const char WIFI_PASS[] = "Micro@123";

SoftwareSerial esp(6, 7);   // RX, TX
Servo servo;

// Sends an AT command and waits for an expected string. Returns true if found.
bool sendCmd(const String &cmd, const char *expect, unsigned long timeout = 3000) {
  esp.println(cmd);
  String resp;
  unsigned long t = millis();
  while (millis() - t < timeout) {
    while (esp.available()) resp += (char)esp.read();
    if (resp.indexOf(expect) >= 0) return true;
  }
  Serial.print(F("Cmd failed: ")); Serial.println(cmd);
  Serial.println(resp);
  return false;
}

void sendResponse(int id, const String &body) {
  String r = F("HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Type: text/html\r\n\r\n");
  r += body;
  esp.print(F("AT+CIPSEND="));
  esp.print(id);
  esp.print(',');
  esp.println(r.length());
  // wait for the '>' prompt
  unsigned long t = millis();
  bool prompt = false;
  while (millis() - t < 2000) {
    if (esp.available() && esp.read() == '>') { prompt = true; break; }
  }
  if (!prompt) return;
  esp.print(r);
  // wait for SEND OK
  String resp;
  t = millis();
  while (millis() - t < 2000 && resp.indexOf("SEND OK") < 0) {
    while (esp.available()) resp += (char)esp.read();
  }
  sendCmd(String(F("AT+CIPCLOSE=")) + id, "OK", 1000);
}

String pageBody() {
  String p = F("<meta name=viewport content='width=device-width,initial-scale=1'>"
               "<body style='font-family:sans-serif;text-align:center'>"
               "<h3>Servo</h3>"
               "<input id=n type=number min=0 max=180 value=90 style=font-size:24px;width:100px> "
               "<button style=font-size:24px onclick=\"a=Math.min(180,Math.max(0,+n.value||0));"
               "fetch('/?a='+a);v.innerText='Angle: '+a\">Set</button>"
               "<h1 id=v>Angle: 90</h1>");
  return p;
}

void setup() {
  Serial.begin(9600);
  esp.begin(9600);
  servo.attach(5);
  servo.write(90);

  Serial.println(F("Resetting ESP..."));
  sendCmd(F("AT+RST"), "ready", 6000);
  sendCmd(F("AT+CWMODE=1"), "OK");
  sendCmd(String(F("AT+CWJAP=\"")) + WIFI_SSID + "\",\"" + WIFI_PASS + "\"", "OK", 15000);
  sendCmd(F("AT+CIPMUX=1"), "OK");
  sendCmd(F("AT+CIPSERVER=1,80"), "OK");

  esp.println(F("AT+CIFSR"));
  delay(1000);
  Serial.println(F("Open the STAIP address below in your browser:"));
  while (esp.available()) Serial.write(esp.read());
}

void loop() {
  if (!esp.available()) return;

  // collect the incoming request
  String req;
  unsigned long t = millis();
  while (millis() - t < 150) {
    while (esp.available()) { req += (char)esp.read(); t = millis(); }
  }

  int ipd = req.indexOf("+IPD,");
  if (ipd < 0) return;
  int id = req.charAt(ipd + 5) - '0';

  int a = req.indexOf("GET /?a=");
  if (a >= 0) {
    int angle = constrain(req.substring(a + 8).toInt(), 0, 180);
    servo.write(angle);
    Serial.print(F("Angle: ")); Serial.println(angle);
    sendResponse(id, "OK");
  } else if (req.indexOf("GET / ") >= 0) {
    sendResponse(id, pageBody());
  } else {
    sendResponse(id, "");   // favicon etc.
  }
}
