/*
  Experiment 6 - IIoT Energy Monitoring & Optimization  (Arduino Uno side)
  Version: voltage and current simulated with two potentiometers (0-5 V)
  --------------------------------------------------------------------------
  What it does
    1. Reads a voltage pot  (A2) -> load voltage V (0 .. V_FULL_SCALE)
    2. Reads a current pot  (A0) -> load current I (0 .. I_FULL_SCALE)
    3. Power (W) = V * I, accumulated into energy (Wh)
    4. Two modes (switch with a serial character, or let the PC script do it):
         'N' = Normal / baseline  : load is always ON
         'O' = Optimized          : load is ON only if someone is present (PIR)
                                    AND it is dark (LDR)
    5. Buzzer alert if power is above POWER_ALERT_W
    6. Prints one CSV line per second:
         DATA,voltage_V,current_A,power_W,energy_Wh,pir,ldr,relay

  Wiring (Arduino Uno)
    Current pot : outer pins 5V and GND, wiper -> A0
    Voltage pot : outer pins 5V and GND, wiper -> A2
    LDR divider -> A1   (LDR from 5V to A1, 10k resistor from A1 to GND,
                         so the reading is LOW in the dark)
    PIR OUT     -> D2
    Relay IN    -> D7   (module VCC 5V, GND)
    Buzzer (+)  -> D8   (active buzzer)

  Note: a pot is independent of the relay, so when the relay is OFF the
  sketch forces the measured current to 0. This is what makes the energy
  savings of the Optimized mode show up in the data.

  Serial: 9600 baud. Educational use only.
*/

// ---------- Pins ----------
const uint8_t PIN_PIR      = 2;
const uint8_t PIN_RELAY    = 7;
const uint8_t PIN_BUZZER   = 8;
const uint8_t PIN_VOLTAGE  = A0;   // voltage potentiometer
const uint8_t PIN_CURRENT  = A1;   // current potentiometer
const uint8_t PIN_LDR      = A2;


// Most relay modules are "active LOW". Swap if yours is active HIGH.
const uint8_t RELAY_ON  = LOW;
const uint8_t RELAY_OFF = HIGH;

// ---------- Settings (tune for your setup) ----------
const float ADC_REF         = 5.0;     // ADC reference voltage (V)
const float V_FULL_SCALE    = 5.0;    // pot at 5 V  -> this many volts of "load voltage"
const float I_FULL_SCALE    = 2.0;     // pot at 5 V  -> this many amps of "load current"
const float POWER_ALERT_W   = 5.0;    // buzzer if power is above this
const int   LDR_DARK_BELOW  = 400;     // ADC value below this = "dark" (calibrate!)
const unsigned long VACANT_AFTER_MS = 10000;  // no motion for 10 s = room empty
const unsigned long REPORT_EVERY_MS = 1000;   // 1 reading per second

// ---------- State ----------
bool  optimizeMode = false;     // false = baseline, true = optimized
float energyWh = 0.0;
unsigned long lastReportMs = 0;
unsigned long lastMotionMs = 0;
bool  motionSeen = false;

// Average several ADC samples and return the pin voltage (0 - 5 V).
float readPinVolts(uint8_t pin) {
  const int N = 32;
  long sum = 0;
  for (int i = 0; i < N; i++) {
    sum += analogRead(pin);
  }
  return (sum / (float)N) * (ADC_REF / 1023.0);
}

// Pot voltage (0-5 V) -> simulated load voltage in volts.
float readVoltage() {
  return readPinVolts(PIN_VOLTAGE) * (V_FULL_SCALE / ADC_REF);
}

// Pot voltage (0-5 V) -> simulated load current in amps.
float readCurrent() {
  return readPinVolts(PIN_CURRENT) * (I_FULL_SCALE / ADC_REF);
}

void readCommands() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'O' || c == 'o') {
      optimizeMode = true;  energyWh = 0;
      Serial.println(F("# Mode: OPTIMIZED"));
    } else if (c == 'N' || c == 'n') {
      optimizeMode = false; energyWh = 0;
      Serial.println(F("# Mode: NORMAL (baseline)"));
    }
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_RELAY, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_RELAY, RELAY_OFF);

  Serial.println(F("# Exp 6 Energy Monitor (potentiometer version)"));
  Serial.println(F("# Ready. Send 'N' (normal) or 'O' (optimized)."));
  Serial.println(F("# Columns: DATA,voltage_V,current_A,power_W,energy_Wh,pir,ldr,relay"));
  lastReportMs = millis();
}

void loop() {
  readCommands();
  unsigned long now = millis();

  // 1) Presence (PIR) and light (LDR)
  if (digitalRead(PIN_PIR) == HIGH) {
    lastMotionMs = now;
    motionSeen = true;
  }
  bool occupied = motionSeen && (now - lastMotionMs < VACANT_AFTER_MS);
  int  ldr = analogRead(PIN_LDR);
  bool dark = ldr < LDR_DARK_BELOW;

  // 2) Decide relay state
  bool relayOn = optimizeMode ? (occupied && dark) : true;
  digitalWrite(PIN_RELAY, relayOn ? RELAY_ON : RELAY_OFF);

  // 3) Once per second: measure, accumulate, alert, report
  if (now - lastReportMs >= REPORT_EVERY_MS) {
    float dtMs = now - lastReportMs;
    lastReportMs = now;

    float voltage = readVoltage();
    voltage = voltage*50;
    float current = relayOn ? readCurrent() : 0.0;   // load OFF -> no current
    float power   = voltage * current;               // P = V * I
    energyWh += power * dtMs / 3600000.0;            // W * hours

    digitalWrite(PIN_BUZZER, power > POWER_ALERT_W ? HIGH : LOW);

    Serial.print(F("DATA,"));
    Serial.print(voltage, 2);  Serial.print(',');
    Serial.print(current, 3);  Serial.print(',');
    Serial.print(power, 2);    Serial.print(',');
    Serial.print(energyWh, 4); Serial.print(',');
    Serial.print(digitalRead(PIN_PIR)); Serial.print(',');
    Serial.print(ldr);         Serial.print(',');
    Serial.println(relayOn ? 1 : 0);
  }
}
