# Experiment 6 - IIoT Energy Monitoring & Optimization

**Aim:** Measure power and energy of a load with an Arduino Uno, then reduce
consumption with presence (PIR) and light (LDR) based control. Compare
energy *with* and *without* optimization.

## Hardware
| Part | Arduino pin |
|---|---|
| ACS712 current sensor OUT | A0 |
| LDR + 10k divider (LDR 5V->A1, 10k A1->GND) | A1 |
| PIR sensor OUT | D2 |
| Relay module IN | D7 |
| Active buzzer (+) | D8 |

Load: a **12 V DC bulb/fan** in series with the ACS712 through the relay (set `SUPPLY_V = 12.0`).
Use mains only under teacher supervision.

## Files
```
arduino/energy_monitor/energy_monitor.ino   Uno sketch
pc/energy_monitor.py                        log + analyze (Windows 11 / Python 3.9+)
requirements.txt
data/                                       CSVs and chart are created here
```

## Steps
1. Open the `.ino` in Arduino IDE, select **Arduino Uno** and the COM port, upload. No extra libraries needed.
2. Keep the load OFF/idle for ~3 s after reset (the sketch calibrates the sensor zero).
3. PowerShell, inside this folder:
   ```
   py -m pip install -r requirements.txt
   py pc\energy_monitor.py ports
   py pc\energy_monitor.py log --port COM3 --mode baseline --seconds 120
   py pc\energy_monitor.py log --port COM3 --mode optimized --seconds 120
   py pc\energy_monitor.py analyze
   ```
   During the optimized run, walk in/out of the PIR's view and cover/uncover the LDR.
4. No hardware yet? `py pc\energy_monitor.py demo`

## Notes
* PIR needs ~30-60 s to warm up after power-on.
* Place the LDR so the bulb's own light does not fall on it, otherwise the lamp "sees itself" and switches off.
* Calibrate `LDR_DARK_BELOW` by reading the LDR value (shown in the CSV) in light and in dark.
* Power factor is assumed 1 - fine for a bulb, approximate for motors.
* Close the Arduino Serial Monitor before running the Python script.
* Educational use only.
