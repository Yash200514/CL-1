"""
Experiment 6 - IIoT Energy Monitoring & Optimization  (PC side, Windows 11)
===========================================================================
What this script does
  * LOG     : reads the CSV lines sent by the Arduino over USB-serial and saves
              them to data/baseline.csv or data/optimized.csv
  * ANALYZE : compares the two runs (energy, average power, saving %) and
              draws a power-vs-time chart + bar chart  -> data/energy_report.png
  * DEMO    : creates fake data for both runs so you can test the analysis
              without any hardware.

Setup (once, in PowerShell inside this experiment folder)
  py -m pip install -r requirements.txt

How to run
  py pc\\energy_monitor.py ports                              # find your COM port
  py pc\\energy_monitor.py log --port COM3 --mode baseline --seconds 120
  py pc\\energy_monitor.py log --port COM3 --mode optimized --seconds 120
  py pc\\energy_monitor.py analyze                            # table + chart
  py pc\\energy_monitor.py demo                               # no hardware needed

Tips
  * Close the Arduino Serial Monitor before running (only one program can use
    the COM port at a time).
  * Do both runs under similar conditions (same room, same duration).
  * SUPPLY_V below is only used by --demo; real power comes from the Arduino.
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BAUD = 9600
SUPPLY_V = 12.0   # demo only - keep equal to SUPPLY_V in the Arduino sketch
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
COLUMNS = ["time_s", "current_A", "power_W", "energy_Wh", "pir", "ldr", "relay"]


def csv_path(mode):
    return os.path.join(DATA_DIR, f"{mode}.csv")


# ---------------------------------------------------------------- ports
def list_ports():
    from serial.tools import list_ports as lp
    ports = list(lp.comports())
    if not ports:
        print("No serial ports found. Is the Arduino plugged in?")
    for p in ports:
        print(f"{p.device}  -  {p.description}")


# ---------------------------------------------------------------- logging
def log_run(port, mode, seconds):
    import serial  # imported here so 'demo' works even without pyserial
    os.makedirs(DATA_DIR, exist_ok=True)
    ser = serial.Serial(port, BAUD, timeout=2)
    time.sleep(2.5)                      # Uno resets when the port opens
    ser.reset_input_buffer()
    ser.write(b"O" if mode == "optimized" else b"N")
    print(f"Logging '{mode}' run for {seconds} s on {port} ... (Ctrl+C to stop early)")

    rows, t0 = [], time.time()
    try:
        while time.time() - t0 < seconds:
            line = ser.readline().decode(errors="ignore").strip()
            if not line.startswith("DATA,"):
                if line:
                    print(line)          # '# ...' messages from the Arduino
                continue
            try:
                vals = [float(v) for v in line.split(",")[1:]]
            except ValueError:
                continue
            if len(vals) != 6:
                continue
            row = dict(zip(COLUMNS, [round(time.time() - t0, 1)] + vals))
            rows.append(row)
            print(f"t={row['time_s']:6.1f}s  I={row['current_A']:.3f} A  "
                  f"P={row['power_W']:.2f} W  relay={int(row['relay'])}")
    except KeyboardInterrupt:
        print("Stopped early.")
    finally:
        ser.close()

    df = pd.DataFrame(rows, columns=COLUMNS)
    df.to_csv(csv_path(mode), index=False)
    print(f"Saved {len(df)} rows -> {os.path.abspath(csv_path(mode))}")


# ---------------------------------------------------------------- demo data
def make_demo(mode, seconds=120):
    """Fake run: a person is in the room 20 s of every 60 s (+10 s hold time)."""
    rng = np.random.default_rng(1 if mode == "baseline" else 2)
    t = np.arange(seconds)
    pir = ((t % 60) < 20).astype(int)
    occupied = ((t % 60) < 30).astype(int)
    relay = np.ones(seconds, int) if mode == "baseline" else occupied
    current = relay * (0.75 + rng.normal(0, 0.01, seconds))
    power = current * SUPPLY_V
    df = pd.DataFrame({
        "time_s": t.astype(float),
        "current_A": current.round(3),
        "power_W": power.round(2),
        "energy_Wh": (np.cumsum(power) / 3600).round(4),
        "pir": pir,
        "ldr": rng.integers(150, 300, seconds),
        "relay": relay,
    })
    os.makedirs(DATA_DIR, exist_ok=True)
    df.to_csv(csv_path(mode), index=False)


# ---------------------------------------------------------------- analysis
def summarize(df):
    dt = df["time_s"].diff().fillna(1.0)                 # seconds between samples
    energy_wh = float((df["power_W"].to_numpy() * dt.to_numpy()).sum() / 3600)
    duration_s = float(dt.sum())
    return {
        "samples": len(df),
        "duration_s": round(duration_s, 1),
        "energy_Wh": round(energy_wh, 3),
        "avg_power_W": round(energy_wh * 3600 / duration_s, 2),
        "peak_power_W": round(float(df["power_W"].max()), 2),
        "relay_on_%": round(float(df["relay"].mean() * 100), 1),
    }


def analyze(show=True):
    runs = {}
    for mode in ("baseline", "optimized"):
        if not os.path.exists(csv_path(mode)):
            sys.exit(f"Missing {csv_path(mode)} - run the 'log' command for "
                     f"'{mode}' first (or use 'demo').")
        runs[mode] = pd.read_csv(csv_path(mode))

    table = pd.DataFrame({m: summarize(df) for m, df in runs.items()})
    print("\n=== Energy comparison ===")
    print(table.to_string())

    base_p = table.loc["avg_power_W", "baseline"]
    opt_p = table.loc["avg_power_W", "optimized"]
    saving = (base_p - opt_p) / base_p * 100 if base_p > 0 else 0.0
    print(f"\nEnergy saving (by average power): {saving:.1f} %")

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 7))
    for mode, df in runs.items():
        ax1.plot(df["time_s"], df["power_W"], label=mode)
    ax1.set_xlabel("Time (s)")
    ax1.set_ylabel("Power (W)")
    ax1.set_title("Power consumption: baseline vs optimized")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    bars = ax2.bar(["baseline", "optimized"], [base_p, opt_p],
                   color=["tab:red", "tab:green"])
    ax2.bar_label(bars, fmt="%.2f W")
    ax2.set_ylabel("Average power (W)")
    ax2.set_title(f"Average power  (saving = {saving:.1f} %)")
    fig.tight_layout()

    out = os.path.join(DATA_DIR, "energy_report.png")
    fig.savefig(out, dpi=120)
    print(f"Chart saved -> {os.path.abspath(out)}")
    if show:
        plt.show()


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Exp 6 - Energy monitoring (PC side)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("ports", help="list serial ports")

    p_log = sub.add_parser("log", help="record a run from the Arduino")
    p_log.add_argument("--port", required=True, help="e.g. COM3")
    p_log.add_argument("--mode", choices=["baseline", "optimized"], required=True)
    p_log.add_argument("--seconds", type=int, default=120)

    p_an = sub.add_parser("analyze", help="compare baseline vs optimized")
    p_an.add_argument("--no-show", action="store_true", help="save chart only")

    sub.add_parser("demo", help="fake data + analysis, no hardware")

    args = ap.parse_args()
    if args.cmd == "ports":
        list_ports()
    elif args.cmd == "log":
        log_run(args.port, args.mode, args.seconds)
    elif args.cmd == "analyze":
        analyze(show=not args.no_show)
    elif args.cmd == "demo":
        make_demo("baseline")
        make_demo("optimized")
        analyze(show=True)


if __name__ == "__main__":
    main()
