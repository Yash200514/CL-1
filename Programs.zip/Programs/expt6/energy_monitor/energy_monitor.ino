/*
  Experiment 6 - IIoT Energy Monitoring & Optimization  (Arduino Uno side)
  --------------------------------------------------------------------------
  What it does
    1. Measures load current with an Potentiometer  -> power (W) = V * I
    2. Accumulates energy (Wh)
    3. Two modes (switch with a serial character, or let the PC script do it):
         'N' = Normal / baseline  : load is always ON
         'O' = Optimized          : load is ON only if someone is present (PIR)
                                    AND it is dark (LDR)
    4. Buzzer alert if power is above POWER_ALERT_W
    5. Prints one CSV line per second:
         DATA,current_A,power_W,energy_Wh,pir,ldr,relay

  Wiring (Arduino Uno)
    ACS712 OUT -> A0          (VCC 5V, GND)
    LDR divider -> A1         (LDR from 5V to A1, 10k resistor from A1 to GND,
                               so the reading is LOW in the dark)
    PIR OUT    -> D2
    Relay IN   -> D7          (module VCC 5V, GND)
    Buzzer (+) -> D8          (active buzzer)

  SAFETY: use a low-voltage DC load (12V bulb / small fan) for the lab.
          Set SUPPLY_V below to that voltage. Mains wiring only under
          teacher supervision.

  Serial: 9600 baud. Educational use only.
*/

// ---------- Pins ----------
const uint8_t PIN_PIR    = 2;
const uint8_t PIN_RELAY  = 7;
const uint8_t PIN_BUZZER = 8;
const uint8_t PIN_POT    = A0;
const uint8_t PIN_LDR    = A1;

// Most relay modules are "active LOW". Swap if yours is active HIGH.
const uint8_t RELAY_ON  = LOW;
const uint8_t RELAY_OFF = HIGH;

// ---------- Settings (tune for your hardware) ----------
const float SUPPLY_V        = 15.0;    // load voltage (V) used for P = V * I
const float POT_SENS        = 0.185;   // V per A: 5A module=0.185, 20A=0.100, 30A=0.066
const float POWER_ALERT_W   = 15.0;    // buzzer if power is above this
const int   LDR_DARK_BELOW  = 400;     // ADC value below this = "dark" (calibrate!)
const unsigned long VACANT_AFTER_MS = 10000;  // no motion for 10 s = room empty
const unsigned long REPORT_EVERY_MS = 1000;   // 1 reading per second

// ---------- State ----------
float offsetAdc = 512.0;        // ACS712 zero-current ADC value (measured at start)
bool  optimizeMode = false;     // false = baseline, true = optimized
float energyWh = 0.0;
unsigned long lastReportMs = 0;
unsigned long lastMotionMs = 0;
bool  motionSeen = false;

// Measure the zero-current offset with the load switched OFF.
void calibrateOffset() {
  digitalWrite(PIN_RELAY, RELAY_OFF);
  delay(500);
  long sum = 0;
  for (int i = 0; i < 500; i++) {
    sum += analogRead(PIN_POT);
    delay(2);
  }
  offsetAdc = sum / 500.0;
}

// RMS current over ~60 ms (3 cycles of 50 Hz). Also works for a DC load.
float readCurrentRms() {
  const int N = 600;
  float sumSq = 0;
  for (int i = 0; i < N; i++) {
    float volts = (analogRead(PIN_POT) - offsetAdc) * (5.0 / 1023.0);
    sumSq += volts * volts;
  }
  float irms = sqrt(sumSq / N) / ACS_SENS;
  if (irms < 0.05) irms = 0;      // ignore sensor noise
  return irms;
}

void readCommands() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'O' || c == 'o') {
      optimizeMode = true;  energyWh = 0;
      Serial.println(F("# Mode: OPTIMIZED"));
    } else if (c == 'N' || c == 'n') {
      optimizeMode = false; energyWh = 0;
      Serial.println(F("# Mode: NORMAL (baseline)"));
    }
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_RELAY, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  Serial.println(F("# Exp 6 Energy Monitor - calibrating current sensor..."));
  calibrateOffset();
  Serial.println(F("# Ready. Send 'N' (normal) or 'O' (optimized)."));
  Serial.println(F("# Columns: DATA,current_A,power_W,energy_Wh,pir,ldr,relay"));
  lastReportMs = millis();
}

void loop() {
  readCommands();
  unsigned long now = millis();

  // 1) Presence (PIR) and light (LDR)
  if (digitalRead(PIN_PIR) == HIGH) {
    lastMotionMs = now;
    motionSeen = true;
  }
  bool occupied = motionSeen && (now - lastMotionMs < VACANT_AFTER_MS);
  int  ldr = analogRead(PIN_LDR);
  bool dark = ldr < LDR_DARK_BELOW;

  // 2) Decide relay state
  bool relayOn = optimizeMode ? (occupied && dark) : true;
  digitalWrite(PIN_RELAY, relayOn ? RELAY_ON : RELAY_OFF);

  // 3) Once per second: measure, accumulate, alert, report
  if (now - lastReportMs >= REPORT_EVERY_MS) {
    float dtMs = now - lastReportMs;
    lastReportMs = now;

    float irms  = readCurrentRms();
    float power = irms * SUPPLY_V;            // assumes power factor = 1
    energyWh += power * dtMs / 3600000.0;     // W * hours

    digitalWrite(PIN_BUZZER, power > POWER_ALERT_W ? HIGH : LOW);

    Serial.print(F("DATA,"));
    Serial.print(irms, 3);   Serial.print(',');
    Serial.print(power, 2);  Serial.print(',');
    Serial.print(energyWh, 4); Serial.print(',');
    Serial.print(digitalRead(PIN_PIR)); Serial.print(',');
    Serial.print(ldr);       Serial.print(',');
    Serial.println(relayOn ? 1 : 0);
  }
}
