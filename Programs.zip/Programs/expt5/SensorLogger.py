
import serial
import sqlite3
import time
from datetime import datetime

# Change COM3 to your Arduino port.
SERIAL_PORT = "COM3"
BAUD_RATE = 9600
DATABASE_FILE = "sensor_data.db"

# Create/open local database.
db = sqlite3.connect(DATABASE_FILE)
cursor = db.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS sensor_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        temperature_c REAL NOT NULL,
        adc_value INTEGER NOT NULL
    )
""")
db.commit()

try:
    with serial.Serial(
        SERIAL_PORT, BAUD_RATE, timeout=2
    ) as ser:

        # Uno may reset when serial port opens.
        time.sleep(2)
        ser.reset_input_buffer()

        print("Logging sensor data to", DATABASE_FILE)
        print("Press Ctrl+C to stop.")

        while True:
            line = ser.readline().decode(
                "utf-8", errors="replace"
            ).strip()

            if not line:
                continue

            try:
                values = line.split(",")

                if len(values) != 2:
                    continue

                temperature = float(values[0])
                adc_value = int(values[1])

                if not 0 <= adc_value <= 1023:
                    continue

                timestamp = datetime.now().astimezone().isoformat(
                    timespec="seconds"
                )

                cursor.execute("""
                    INSERT INTO sensor_readings
                    (timestamp, temperature_c, adc_value)
                    VALUES (?, ?, ?)
                """, (timestamp, temperature, adc_value))

                db.commit()

                print(
                    timestamp,
                    f"Temperature={temperature:.2f} C",
                    f"ADC={adc_value}"
                )

            except (ValueError, OverflowError):
                print("Skipping invalid line:", repr(line))

except KeyboardInterrupt:
    print("\nLogging stopped.")

except serial.SerialException as error:
    print("Serial connection error:", error)

finally:
    db.close()
    print("Database closed.")
