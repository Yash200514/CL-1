#define SENSOR_PIN A0

void setup()
{
  Serial.begin(9600);
}

void loop()
{
  int adcValue = analogRead(SENSOR_PIN);

  float voltage = adcValue * (5.0 / 1023.0);
  float temperatureC = voltage * 100.0;

  // CSV format: temperature,ADC value
  Serial.print(temperatureC, 2);
  Serial.print(",");
  Serial.println(adcValue);

  delay(2000);
}
