"""
Experiment 8 - Security Measures in an IIoT System  (PC "gateway" side, Windows 11)
===================================================================================
What this script does
  The PC plays two roles:
    GATEWAY  - receives sensor packets from the Arduino and checks them.
    ATTACKER - captures packets and then (a) REPLAYS an old packet and
               (b) TAMPERS with a packet's value.
  It runs the attack twice:
    1. UNSECURED mode  ("U,<value>")                  -> attacks SUCCEED
    2. SECURED mode    ("S,<counter>,<value>,<HMAC>") -> attacks are REJECTED
       (HMAC-SHA256 catches tampering, the counter catches replay)
  A final table summarises what happened.

  Layer 1 (RFID / lockout) and Layer 3 (tamper switch) run on the Arduino;
  their EVENT / ALERT messages are printed here while the script is running.

Setup (once, PowerShell inside this experiment folder)
  py -m pip install -r requirements.txt

How to run
  py pc\\iiot_security_demo.py --port COM3        # with the Arduino
  py pc\\iiot_security_demo.py --demo             # no hardware, simulated packets
  py pc\\iiot_security_demo.py --list-ports       # find the COM port

Notes
  * SECRET_KEY must be identical to SECRET_KEY in the Arduino sketch.
  * Close the Arduino Serial Monitor first (one program per COM port).
  * Educational demo only - real systems never hard-code keys.
"""
import argparse
import hashlib
import hmac
import time

import numpy as np
import pandas as pd

BAUD = 9600
SECRET_KEY = b"EduKey123"      # same as the Arduino sketch
MAC_HEX_LEN = 16               # 8 bytes shown as 16 hex characters
PACKETS_PER_MODE = 5


# ------------------------------------------------------------ crypto helpers
def make_mac(counter, value):
    """HMAC-SHA256 over the text '<counter>,<value>' (same as the Arduino)."""
    msg = f"{counter},{value}".encode()
    return hmac.new(SECRET_KEY, msg, hashlib.sha256).hexdigest()[:MAC_HEX_LEN]


class Gateway:
    """Checks incoming packets. 'secure' decides whether it verifies anything."""

    def __init__(self, secure):
        self.secure = secure
        self.last_counter = 0

    def check(self, packet):
        parts = packet.strip().split(",")
        try:
            if not self.secure:
                if len(parts) == 2 and parts[0] == "U":
                    int(parts[1])
                    return True, "accepted (no checks done)"
                return False, "bad format"

            if len(parts) != 4 or parts[0] != "S":
                return False, "bad format"
            counter, value, mac = int(parts[1]), int(parts[2]), parts[3].lower()
        except ValueError:
            return False, "bad format"

        if not hmac.compare_digest(mac, make_mac(counter, value)):
            return False, "REJECTED: HMAC mismatch (tampered)"
        if counter <= self.last_counter:
            return False, "REJECTED: old counter (replay)"
        self.last_counter = counter
        return True, "accepted (HMAC + counter OK)"


# ------------------------------------------------------------ attacker
def tamper(packet):
    """Change the sensor value but keep everything else (incl. the old HMAC)."""
    parts = packet.split(",")
    idx = 1 if parts[0] == "U" else 2
    parts[idx] = str(int(parts[idx]) + 500)
    return ",".join(parts)


def run_attacks(secure, packets):
    gw = Gateway(secure)
    rows = []
    for p in packets:
        ok, why = gw.check(p)
        rows.append(["normal traffic", p, ok, why])

    replayed = packets[0]                      # attacker re-sends an OLD packet
    ok, why = gw.check(replayed)
    rows.append(["REPLAY attack", replayed, ok, why])

    forged = tamper(packets[-1])               # attacker edits the value
    ok, why = gw.check(forged)
    rows.append(["TAMPER attack", forged, ok, why])

    return pd.DataFrame(rows, columns=["step", "packet", "accepted", "reason"])


# ------------------------------------------------------------ packet sources
def demo_packets(secure, n):
    rng = np.random.default_rng(7)
    values = rng.integers(300, 700, n)
    if not secure:
        return [f"U,{v}" for v in values]
    return [f"S,{i + 1},{v},{make_mac(i + 1, v)}" for i, v in enumerate(values)]


def serial_packets(ser, secure, n, timeout=40):
    ser.write(b"MODE S\n" if secure else b"MODE U\n")
    prefix = "S," if secure else "U,"
    packets, t0 = [], time.time()
    while len(packets) < n and time.time() - t0 < timeout:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue
        if line.startswith(("EVENT", "ALERT")):
            print(f"   [Arduino] {line}")
        elif line.startswith(prefix):
            packets.append(line)
    if len(packets) < n:
        raise SystemExit("Not enough packets received - check port, baud and sketch.")
    return packets


# ------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description="Exp 8 - IIoT security demo")
    ap.add_argument("--port", help="serial port, e.g. COM3")
    ap.add_argument("--demo", action="store_true", help="simulate packets, no hardware")
    ap.add_argument("--list-ports", action="store_true")
    args = ap.parse_args()

    if args.list_ports:
        from serial.tools import list_ports
        for p in list_ports.comports():
            print(f"{p.device}  -  {p.description}")
        return
    if not args.demo and not args.port:
        ap.error("give --port COMx or use --demo")

    ser = None
    if not args.demo:
        import serial
        ser = serial.Serial(args.port, BAUD, timeout=2)
        time.sleep(2.5)                  # Uno resets when the port opens
        ser.reset_input_buffer()

    verdicts = []
    for secure in (False, True):
        name = "SECURED (HMAC + counter)" if secure else "UNSECURED (plain)"
        print(f"\n=========== {name} ===========")
        if args.demo:
            packets = demo_packets(secure, PACKETS_PER_MODE)
        else:
            packets = serial_packets(ser, secure, PACKETS_PER_MODE)
        table = run_attacks(secure, packets)
        print(table.to_string(index=False))
        attacks = table[table["step"].str.contains("attack")]
        succeeded = bool(attacks["accepted"].all())
        verdicts.append([name, int(attacks["accepted"].sum()), len(attacks),
                         "ATTACK SUCCEEDED" if succeeded else "ATTACKS BLOCKED"])

    print("\n=========== SUMMARY ===========")
    print(pd.DataFrame(verdicts, columns=["mode", "attacks accepted", "attacks tried",
                                          "result"]).to_string(index=False))
    if ser:
        ser.close()


if __name__ == "__main__":
    main()
