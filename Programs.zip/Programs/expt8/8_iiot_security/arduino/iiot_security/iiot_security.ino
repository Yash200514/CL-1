/*
  Experiment 8 - Security Measures in an IIoT System  (Arduino Uno side)
  --------------------------------------------------------------------------
  Three small security layers:

   Layer 1  ACCESS CONTROL  : RFID card (RC522) -> green LED = access granted.
                              3 wrong attempts -> 15 s lockout + buzzer.
                              (No RC522? set USE_RFID 0 and type "PIN 1234"
                               in the Serial Monitor instead.)
   Layer 2  MESSAGE SECURITY: sensor packets are sent in two modes
                              U = unsecured : "U,<value>"
                              S = secured   : "S,<counter>,<value>,<HMAC>"
                              HMAC-SHA256 (first 8 bytes) with a shared key,
                              plus an increasing counter to stop replay attacks.
   Layer 3  TAMPER DETECTION: push button / reed switch on D3 -> ALERT + buzzer.

  The PC script (pc/iiot_security_demo.py) switches modes and performs the
  replay / tampering attack demo.

  Libraries (Arduino IDE -> Library Manager):
    - "Crypto"   by Rhys Weatherley   (SHA256 / HMAC)
    - "MFRC522"  by GithubCommunity   (only if USE_RFID 1)

  Wiring
    RC522: SDA->D10, SCK->D13, MOSI->D11, MISO->D12, RST->D9, 3.3V, GND
           (!! RC522 is a 3.3 V device - do NOT connect it to 5 V)
    Green LED -> D6 (with 220R)   Red LED -> D5 (with 220R)
    Buzzer (+) -> D8 (active)
    Tamper switch between D3 and GND (INPUT_PULLUP: pressed = tamper)
    Sensor: potentiometer / LDR / LM35 -> A0 (any analog value is fine)

  Serial: 9600 baud, line ending "Newline" in Serial Monitor.
  Educational demo only - a hard-coded key is NOT real-world security.
*/

#include <Crypto.h>
#include <SHA256.h>

#define USE_RFID 1            // 1 = RC522 card reader, 0 = type "PIN 1234" in Serial Monitor

#if USE_RFID
  #include <SPI.h>
  #include <MFRC522.h>
  const uint8_t RFID_SS_PIN = 10;
  const uint8_t RFID_RST_PIN = 9;
  MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);
  // Put YOUR card's UID here. Scan the card once and read it from the Serial Monitor.
  const byte AUTH_UID[4] = {0xDE, 0xAD, 0xBE, 0xEF};
#else
  const char AUTH_PIN[] = "1234";
#endif

// ---------- Shared secret (must match SECRET_KEY in the Python script) ----------
const char SECRET_KEY[] = "EduKey123";

// ---------- Pins ----------
const uint8_t PIN_GREEN  = 6;
const uint8_t PIN_RED    = 5;
const uint8_t PIN_BUZZER = 8;
const uint8_t PIN_TAMPER = 3;
const uint8_t PIN_SENSOR = A0;

// ---------- Settings ----------
const uint8_t MAX_FAILS = 3;
const unsigned long LOCKOUT_MS = 15000;
const unsigned long GREEN_ON_MS = 3000;
const unsigned long SEND_EVERY_MS = 1000;

// ---------- State ----------
bool secureMode = false;
unsigned long counter = 0;
uint8_t failedAttempts = 0;
unsigned long lockUntil = 0;
unsigned long greenOffAt = 0;
unsigned long lastSendMs = 0;
bool tamperReported = false;
char lineBuf[24];
uint8_t lineLen = 0;

// ================= Layer 1: access control =================
void handleAuth(bool ok) {
  if (millis() < lockUntil) {
    Serial.println(F("EVENT,LOCKED_OUT"));
    return;
  }
  if (ok) {
    failedAttempts = 0;
    digitalWrite(PIN_GREEN, HIGH);
    greenOffAt = millis() + GREEN_ON_MS;
    Serial.println(F("EVENT,ACCESS_GRANTED"));
  } else {
    failedAttempts++;
    Serial.print(F("EVENT,ACCESS_DENIED,attempt="));
    Serial.println(failedAttempts);
    if (failedAttempts >= MAX_FAILS) {
      lockUntil = millis() + LOCKOUT_MS;
      failedAttempts = 0;
      Serial.println(F("ALERT,LOCKOUT"));
    }
  }
}

#if USE_RFID
void checkRfid() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;

  Serial.print(F("EVENT,CARD_UID,"));
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) Serial.print('0');
    Serial.print(rfid.uid.uidByte[i], HEX);
  }
  Serial.println();

  bool ok = (rfid.uid.size == 4) && (memcmp(rfid.uid.uidByte, AUTH_UID, 4) == 0);
  rfid.PICC_HaltA();
  handleAuth(ok);
}
#endif

// ================= Layer 2: packets =================
void sendPacket() {
  int value = analogRead(PIN_SENSOR);

  if (!secureMode) {
    Serial.print(F("U,"));
    Serial.println(value);
    return;
  }

  counter++;
  char msg[24];
  snprintf(msg, sizeof(msg), "%lu,%d", counter, value);   // e.g. "7,512"

  uint8_t mac[32];
  SHA256 sha;
  sha.resetHMAC(SECRET_KEY, strlen(SECRET_KEY));
  sha.update(msg, strlen(msg));
  sha.finalizeHMAC(SECRET_KEY, strlen(SECRET_KEY), mac, sizeof(mac));

  Serial.print(F("S,"));
  Serial.print(msg);
  Serial.print(',');
  for (uint8_t i = 0; i < 8; i++) {          // first 8 bytes = 16 hex chars
    if (mac[i] < 0x10) Serial.print('0');
    Serial.print(mac[i], HEX);
  }
  Serial.println();
}

// ================= Layer 3: tamper =================
void checkTamper() {
  bool tampered = (digitalRead(PIN_TAMPER) == LOW);
  if (tampered && !tamperReported) {
    Serial.println(F("ALERT,TAMPER"));
    tamperReported = true;
  }
  if (!tampered) tamperReported = false;
}

// ================= Serial commands =================
void handleLine(const char* s) {
  if (strcmp(s, "MODE S") == 0) {
    secureMode = true;  counter = 0;
    Serial.println(F("EVENT,MODE_SECURE"));
  } else if (strcmp(s, "MODE U") == 0) {
    secureMode = false;
    Serial.println(F("EVENT,MODE_UNSECURE"));
  }
#if !USE_RFID
  else if (strncmp(s, "PIN ", 4) == 0) {
    handleAuth(strcmp(s + 4, AUTH_PIN) == 0);
  }
#endif
}

void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      lineBuf[lineLen] = 0;
      handleLine(lineBuf);
      lineLen = 0;
    } else if (lineLen < sizeof(lineBuf) - 1) {
      lineBuf[lineLen++] = c;
    }
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_GREEN, OUTPUT);
  pinMode(PIN_RED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_TAMPER, INPUT_PULLUP);
#if USE_RFID
  SPI.begin();
  rfid.PCD_Init();
#endif
  Serial.println(F("# Exp 8 IIoT Security ready. Commands: 'MODE S' / 'MODE U'"));
  lastSendMs = millis();
}

void loop() {
  readSerial();
#if USE_RFID
  checkRfid();
#endif
  checkTamper();

  unsigned long now = millis();
  bool locked = now < lockUntil;
  bool tampered = (digitalRead(PIN_TAMPER) == LOW);

  if (greenOffAt != 0 && now >= greenOffAt) {
    digitalWrite(PIN_GREEN, LOW);
    greenOffAt = 0;
  }
  digitalWrite(PIN_RED, locked ? HIGH : LOW);
  digitalWrite(PIN_BUZZER, (locked || tampered) ? HIGH : LOW);

  if (now - lastSendMs >= SEND_EVERY_MS) {
    lastSendMs = now;
    sendPacket();
  }
}
