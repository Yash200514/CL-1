# Experiment 8 - Security Measures in an IIoT System

**Aim:** Demonstrate three basic IIoT security layers on an Arduino Uno, and show
why they matter by running a replay and a tampering attack against unsecured
and secured sensor messages.

| Layer | Idea | Where |
|---|---|---|
| 1. Access control | RFID card, 3 wrong tries = lockout + buzzer | Arduino |
| 2. Message security | HMAC-SHA256 + counter vs. plain text | Arduino + PC |
| 3. Tamper detection | Switch opened -> alert + buzzer | Arduino |

## Hardware
| Part | Pin |
|---|---|
| RC522 RFID (3.3 V only!) | SDA D10, SCK D13, MOSI D11, MISO D12, RST D9 |
| Green LED / Red LED (220 ohm each) | D6 / D5 |
| Active buzzer | D8 |
| Tamper push button (other leg to GND) | D3 |
| Potentiometer or LDR (as "sensor") | A0 |

No RC522? Set `#define USE_RFID 0` in the sketch and type `PIN 1234` in the Serial Monitor (line ending: Newline).

## Files
```
arduino/iiot_security/iiot_security.ino   Uno sketch
pc/iiot_security_demo.py                  gateway + attacker demo (Windows 11 / Python 3.9+)
requirements.txt
```

## Steps
1. Arduino IDE -> Library Manager: install **Crypto** (Rhys Weatherley) and **MFRC522**.
2. Upload the sketch. Open Serial Monitor (9600), scan your card once, copy the `CARD_UID` into `AUTH_UID`, upload again.
3. Test layers 1 and 3 by hand (watch the Serial Monitor, then close it):
   * Authorized card -> green LED. Wrong card 3 times -> red LED + buzzer for 15 s.
   * Press the tamper button -> `ALERT,TAMPER` + buzzer.
4. Run the attack demo (PowerShell in this folder):
   ```
   py -m pip install -r requirements.txt
   py pc\iiot_security_demo.py --list-ports
   py pc\iiot_security_demo.py --port COM3
   ```
   No hardware? `py pc\iiot_security_demo.py --demo`

## Expected result
* UNSECURED: replayed and tampered packets are both **accepted**.
* SECURED: tampered packet -> **HMAC mismatch**; replayed packet -> **old counter**.

## Notes / limitations (good viva points)
* The Uno resets when the serial port opens, so the counter restarts at each session. Real devices keep it in EEPROM/secure storage.
* The key is hard-coded for teaching. Real systems use per-device keys, secure elements and key rotation.
* HMAC gives integrity + authenticity, **not** secrecy; use encryption (e.g. AES/TLS) for confidentiality.
* Educational use only.
