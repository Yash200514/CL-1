
#define PIR_PIN     2
#define LED_PIN     7
#define BUZZER_PIN  3
#define TEMP_PIN    A0

bool manualMode = false;
bool ledState = false;
bool buzzerState = false;
int previousMotion = LOW;

unsigned long lastReport = 0;

void processCommand(char *cmd)
{
  if (strcmp(cmd, "MODE,AUTO") == 0) {
    manualMode = false;
    Serial.println("INFO,Automatic mode enabled");
  }
  else if (strcmp(cmd, "MODE,MANUAL") == 0) {
    manualMode = true;
    Serial.println("INFO,Manual mode enabled");
  }
  else if (strcmp(cmd, "LED,1") == 0 && manualMode) {
    ledState = true;
  }
  else if (strcmp(cmd, "LED,0") == 0 && manualMode) {
    ledState = false;
  }
  else if (strcmp(cmd, "BUZZER,1") == 0 && manualMode) {
    buzzerState = true;
  }
  else if (strcmp(cmd, "BUZZER,0") == 0 && manualMode) {
    buzzerState = false;
  }
  else if (strcmp(cmd, "ALL_OFF") == 0) {
    ledState = false;
    buzzerState = false;
  }
}

void setup()
{
  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Serial.begin(9600);
  Serial.setTimeout(30);

  Serial.println("INFO,CPS controller started");
}

void loop()
{
  // Receive one newline-terminated command.
  if (Serial.available()) {
    char cmd[40];
    size_t n = Serial.readBytesUntil('\n', cmd, sizeof(cmd) - 1);
    cmd[n] = '\0';

    // Remove trailing carriage return.
    if (n > 0 && cmd[n - 1] == '\r') {
      cmd[n - 1] = '\0';
    }

    processCommand(cmd);
  }

  int motion = digitalRead(PIR_PIN);
  int adc = analogRead(TEMP_PIN);

  // Approximate LM35 conversion, assuming 5 V ADC reference.
  float temperatureC = adc * (500.0 / 1023.0);

  if (!manualMode) {
    ledState = (motion == HIGH);
    buzzerState = (motion == HIGH);
  }

  digitalWrite(LED_PIN, ledState ? LOW : HIGH);
  digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);

  if (motion == HIGH && previousMotion == LOW) {
    Serial.println("EVENT,MOTION_DETECTED");
  }
  previousMotion = motion;

  // Report readings twice per second.
  if (millis() - lastReport >= 500) {
    lastReport = millis();

    Serial.print("DATA,");
    Serial.print(motion);
    Serial.print(",");
    Serial.print(temperatureC, 1);
    Serial.print(",");
    Serial.print(ledState ? 1 : 0);
    Serial.print(",");
    Serial.print(buzzerState ? 1 : 0);
    Serial.print(",");
    Serial.println(manualMode ? "MANUAL" : "AUTO");
  }
}
