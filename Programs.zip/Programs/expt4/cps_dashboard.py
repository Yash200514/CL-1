
import tkinter as tk
from tkinter import ttk, messagebox
import serial
import threading
import queue
import sqlite3
from datetime import datetime

PORT = "COM3"       # Change to your Arduino COM port
BAUD = 9600
DB_FILE = "cps_monitor.db"

root = tk.Tk()
root.title("CPS Monitoring and Control")
root.geometry("760x560")
root.minsize(650, 480)

rx_queue = queue.Queue()
ser = None
running = True
current_mode = "AUTO"

# Local database
db = sqlite3.connect(DB_FILE)
db.execute("""
CREATE TABLE IF NOT EXISTS readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    motion INTEGER,
    temperature REAL,
    led INTEGER,
    buzzer INTEGER,
    mode TEXT
)
""")
db.execute("""
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    event TEXT
)
""")
db.commit()


def timestamp():
    return datetime.now().astimezone().isoformat(
        timespec="seconds"
    )


def send_command(command):
    if ser is None or not ser.is_open:
        messagebox.showwarning(
            "Not connected", "Connect to the Arduino first."
        )
        return

    try:
        ser.write((command + "\n").encode("ascii"))
    except serial.SerialException as exc:
        messagebox.showerror("Serial error", str(exc))


def reader_thread():
    while running and ser and ser.is_open:
        try:
            line = ser.readline().decode(
                "utf-8", errors="replace"
            ).strip()

            if line:
                rx_queue.put(line)

        except (serial.SerialException, OSError) as exc:
            rx_queue.put("ERROR," + str(exc))
            break


def connect_arduino():
    global ser

    try:
        ser = serial.Serial(PORT, BAUD, timeout=1)
        status_var.set("Connected to " + PORT)

        # Opening the Uno serial port normally resets it.
        root.after(2000, start_reader)

    except (serial.SerialException, OSError) as exc:
        status_var.set("Disconnected")
        messagebox.showerror(
            "Connection failed",
            f"Could not open {PORT}:\n{exc}\n\n"
            "Check the COM port and close Arduino Serial Monitor."
        )


def start_reader():
    if ser and ser.is_open:
        threading.Thread(
            target=reader_thread, daemon=True
        ).start()


def set_mode(mode):
    global current_mode
    current_mode = mode
    send_command("MODE," + mode)
    mode_var.set(mode)


def all_off():
    send_command("ALL_OFF")


def process_messages():
    while not rx_queue.empty():
        line = rx_queue.get()

        if line.startswith("ERROR,"):
            status_var.set("Serial error")
            log_event(line[6:])
            continue

        fields = line.split(",")

        if fields[0] == "DATA" and len(fields) == 6:
            try:
                motion = int(fields[1])
                temp = float(fields[2])
                led = int(fields[3])
                buzzer = int(fields[4])
                mode = fields[5]

                motion_var.set(
                    "MOTION DETECTED" if motion else "No motion"
                )
                temp_var.set(f"{temp:.1f} °C")
                led_var.set("ON" if led else "OFF")
                buzzer_var.set("ON" if buzzer else "OFF")
                mode_var.set(mode)

                db.execute("""
                    INSERT INTO readings
                    (timestamp, motion, temperature, led, buzzer, mode)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    timestamp(), motion, temp,
                    led, buzzer, mode
                ))
                db.commit()

            except (ValueError, sqlite3.Error) as exc:
                status_var.set("Data error: " + str(exc))

        elif fields[0] == "EVENT":
            event = ",".join(fields[1:])
            log_event(event)

        elif fields[0] == "INFO":
            status_var.set(",".join(fields[1:]))

    root.after(100, process_messages)


def log_event(event):
    ts = timestamp()
    event_list.insert(0, f"{ts}  |  {event}")
    db.execute(
        "INSERT INTO events (timestamp, event) VALUES (?, ?)",
        (ts, event)
    )
    db.commit()


# Dashboard header
ttk.Label(
    root, text="CPS MONITORING DASHBOARD",
    font=("Segoe UI", 18, "bold")
).pack(pady=(15, 5))

status_var = tk.StringVar(value="Connecting...")
ttk.Label(root, textvariable=status_var).pack()

# Live sensor values
live = ttk.LabelFrame(root, text="Live System Status", padding=15)
live.pack(fill="x", padx=18, pady=12)

motion_var = tk.StringVar(value="Waiting...")
temp_var = tk.StringVar(value="-- °C")
led_var = tk.StringVar(value="--")
buzzer_var = tk.StringVar(value="--")
mode_var = tk.StringVar(value="AUTO")

for col, (title, variable) in enumerate([
    ("PIR Motion", motion_var),
    ("Temperature", temp_var),
    ("LED", led_var),
    ("Buzzer", buzzer_var),
]):
    live.columnconfigure(col, weight=1)
    ttk.Label(
        live, text=title, font=("Segoe UI", 10, "bold")
    ).grid(row=0, column=col, padx=6, pady=5)

    ttk.Label(
        live, textvariable=variable,
        font=("Segoe UI", 12)
    ).grid(row=1, column=col, padx=6, pady=8)

# Operating mode
mode_frame = ttk.LabelFrame(
    root, text="Operating Mode", padding=10
)
mode_frame.pack(fill="x", padx=18, pady=5)

ttk.Label(
    mode_frame, text="Current mode:"
).pack(side="left", padx=5)

ttk.Label(
    mode_frame, textvariable=mode_var,
    font=("Segoe UI", 10, "bold")
).pack(side="left", padx=5)

ttk.Button(
    mode_frame, text="Automatic",
    command=lambda: set_mode("AUTO")
).pack(side="right", padx=5)

ttk.Button(
    mode_frame, text="Manual",
    command=lambda: set_mode("MANUAL")
).pack(side="right", padx=5)

# Actuator controls
controls = ttk.LabelFrame(
    root, text="Manual Controls", padding=10
)
controls.pack(fill="x", padx=18, pady=8)

ttk.Button(
    controls, text="LED ON",
    command=lambda: send_command("LED,1")
).pack(side="left", padx=5)

ttk.Button(
    controls, text="LED OFF",
    command=lambda: send_command("LED,0")
).pack(side="left", padx=5)

ttk.Button(
    controls, text="Buzzer ON",
    command=lambda: send_command("BUZZER,1")
).pack(side="left", padx=5)

ttk.Button(
    controls, text="Buzzer OFF",
    command=lambda: send_command("BUZZER,0")
).pack(side="left", padx=5)

ttk.Button(
    controls, text="All Outputs OFF",
    command=all_off
).pack(side="right", padx=5)

# Event log
event_frame = ttk.LabelFrame(
    root, text="Recent Events", padding=8
)
event_frame.pack(fill="both", expand=True, padx=18, pady=8)

event_list = tk.Listbox(event_frame, height=7)
event_list.pack(fill="both", expand=True)

def close_app():
    global running
    running = False

    try:
        if ser and ser.is_open:
            ser.close()
    except serial.SerialException:
        pass

    db.close()
    root.destroy()


root.protocol("WM_DELETE_WINDOW", close_app)

connect_arduino()
root.after(100, process_messages)
root.mainloop()
