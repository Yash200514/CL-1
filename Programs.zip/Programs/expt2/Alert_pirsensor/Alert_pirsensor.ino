
const int PIR_PIN = 2;
const int BUZZER_PIN = 3;
const int LED_PIN = 6;

int previousMotion = LOW;

void setup()
{
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  Serial.begin(9600);

  Serial.println("Motion Alert System Started");
  Serial.println("Waiting for PIR sensor...");
  
  delay(30000);  // Allow PIR sensor to stabilize
  previousMotion = digitalRead(PIR_PIN);
}

void loop()
{
  int currentMotion = digitalRead(PIR_PIN);

  // Alert only when motion first appears.
  if (currentMotion == HIGH && previousMotion == LOW)
  {
    Serial.println("ALERT: Motion detected!");
    digitalWrite(LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, HIGH);
  }

  // Motion has stopped.
  if (currentMotion == LOW && previousMotion == HIGH)
  {
    Serial.println("INFO: Motion ended.");
    digitalWrite(LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
  }

  previousMotion = currentMotion;
  delay(50);
}
