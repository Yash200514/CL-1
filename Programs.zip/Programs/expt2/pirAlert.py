
import serial
from datetime import datetime

PORT = "COM3"
BAUD = 9600

try:
    with serial.Serial(PORT, BAUD, timeout=1) as arduino:
        print("Motion alert listener running...")
        print("Press Ctrl+C to stop.")

        while True:
            message = arduino.readline().decode(
                "utf-8", errors="replace"
            ).strip()

            if message.startswith("ALERT:"):
                timestamp = datetime.now().astimezone().isoformat(
                    timespec="seconds"
                )
                print(f"\n*** {timestamp} ***")
                print(message)
                print("\a", end="", flush=True)

            elif message.startswith("INFO:"):
                print(message)

except KeyboardInterrupt:
    print("\nAlert listener stopped.")

except serial.SerialException as error:
    print("Serial error:", error)
